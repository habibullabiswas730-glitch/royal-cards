import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const Color _red = Color(0xFF9D1018);
const Color _redDark = Color(0xFF62060A);
const Color _redSoft = Color(0xFFFFF0F1);
const Color _green = Color(0xFF159447);
const Color _ink = Color(0xFF202124);

String _gameTitle(String game) {
  switch (game) {
    case 'teenPatti':
      return 'Teen Patti';
    case 'poker':
      return 'Poker';
    case 'andarBahar':
      return 'Andar Bahar';
    default:
      return 'Rummy';
  }
}

List<String> _freshDeck() {
  const suits = ['♠', '♥', '♦', '♣'];
  const ranks = [
    'A',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    'J',
    'Q',
    'K'
  ];

  return [
    for (final suit in suits)
      for (final rank in ranks) '$rank$suit'
  ];
}

Map<String, dynamic> _dealCards(
  String game,
  List<String> players,
) {
  final deck = <String>[];
  final deckCount = game == 'rummy' ? 2 : 1;
  for (var d = 0; d < deckCount; d++) {
    deck.addAll(_freshDeck());
  }
  deck.shuffle(Random());

  final hands = <String, List<String>>{
    for (final uid in players) uid: [],
  };

  final count = game == 'rummy'
      ? 13
      : game == 'teenPatti'
          ? 3
          : game == 'poker'
              ? 2
              : 1;

  for (var i = 0; i < count; i++) {
    for (final uid in players) {
      if (deck.isNotEmpty) {
        hands[uid]!.add(deck.removeLast());
      }
    }
  }

  final state = <String, dynamic>{
    'deck': deck,
    'hands': hands,
    'community': <String>[],
    'discardPile': <String>[],
    'phase': game == 'rummy' ? 'draw' : 'play',
    'droppedUids': <String>[],
    'winnerUid': '',
    'started': true,
  };

  if (game == 'rummy' && deck.isNotEmpty) {
    state['discardPile'] = [deck.removeLast()];
  }

  if (game == 'poker') {
    final take = min(5, deck.length);

    state['community'] = deck.take(take).toList();

    if (take > 0) {
      deck.removeRange(0, take);
    }
  }

  if (game == 'andarBahar') {
    state['joker'] =
        deck.isNotEmpty ? deck.removeLast() : '';

    state['side'] = 'Andar';
  }

  return state;
}

/// Online room screen used by the Royal Cards app.
class RoomPage extends StatelessWidget {
  final dynamic state;
  final String roomId;

  const RoomPage({
    super.key,
    required this.state,
    required this.roomId,
  });

  Future<void> _invite(
    BuildContext context,
    Map<String, dynamic> room,
  ) async {
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Invite a friend'),
        content: SizedBox(
          width: double.maxFinite,
          child: StreamBuilder<
              QuerySnapshot<Map<String, dynamic>>>(
            stream: state.fb.friends(),
            builder: (context, snap) {
              if (snap.hasError) {
                return Text(
                  'Unable to load friends: ${snap.error}',
                );
              }

              final docs = snap.data?.docs ?? [];

              if (docs.isEmpty) {
                return const Text(
                  'Add a friend first.',
                );
              }

              return ListView(
                shrinkWrap: true,
                children: docs.map((doc) {
                  final friend = doc.data();

                  return ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.person),
                    ),
                    title: Text(
                      (
                        friend['name'] ??
                        friend['playerName'] ??
                        'Player'
                      ).toString(),
                    ),
                    subtitle: Text(
                      friend['online'] == true
                          ? 'Online'
                          : 'Offline',
                    ),
                    trailing: FilledButton(
                      onPressed: () async {
                        try {
                          await state.fb.invite(
                            toUid: doc.id,
                            roomId: roomId,
                            game: (
                              room['game'] ??
                              'rummy'
                            ).toString(),
                          );

                          if (context.mounted) {
                            Navigator.pop(context);

                            ScaffoldMessenger.of(context)
                                .showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Invite sent',
                                ),
                              ),
                            );
                          }
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context)
                                .showSnackBar(
                              SnackBar(
                                content: Text(
                                  e.toString(),
                                ),
                              ),
                            );
                          }
                        }
                      },
                      child: const Text('INVITE'),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<
        DocumentSnapshot<Map<String, dynamic>>>(
      stream: state.fb.room(roomId),
      builder: (context, roomSnap) {
        if (roomSnap.connectionState ==
                ConnectionState.waiting &&
            !roomSnap.hasData) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        if (roomSnap.hasError) {
          return Scaffold(
            body: Center(
              child: Text(
                'Room error: ${roomSnap.error}',
              ),
            ),
          );
        }

        final room = roomSnap.data?.data();

        if (room == null) {
          return const Scaffold(
            body: Center(
              child: Text('Room closed'),
            ),
          );
        }

        final game =
            (room['game'] ?? 'rummy').toString();

        final title = _gameTitle(game);

        return Scaffold(
          appBar: AppBar(
            title: Text('$title Room'),
          ),
          body: StreamBuilder<
              QuerySnapshot<Map<String, dynamic>>>(
            stream: state.fb.roomPlayers(roomId),
            builder: (context, playerSnap) {
              if (playerSnap.hasError) {
                return Center(
                  child: Text(
                    'Players error: ${playerSnap.error}',
                  ),
                );
              }

              final players =
                  playerSnap.data?.docs ?? [];

              final isHost =
                  room['ownerId'] == state.uid;

              final seats =
                  (room['seats'] ?? 4).toString();

              final status =
                  (room['status'] ?? 'waiting')
                      .toString();

              return ListView(
                padding: const EdgeInsets.all(18),
                children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          _redDark,
                          _red,
                        ],
                      ),
                      borderRadius:
                          BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          roomId,
                          style: const TextStyle(
                            color: Colors.white70,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 28,
                            fontWeight:
                                FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${players.length}/$seats players • $status',
                          style: const TextStyle(
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),

                  const Text(
                    'Players',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),

                  const SizedBox(height: 8),

                  ...players.map((doc) {
                    final player = doc.data();

                    final name = (
                      player['name'] ??
                      player['playerName'] ??
                      'Player'
                    ).toString();

                    final host =
                        doc.id == room['ownerId'];

                    return Card(
                      child: ListTile(
                        leading:
                            const CircleAvatar(
                          child: Icon(
                            Icons.person,
                          ),
                        ),
                        title: Text(name),
                        subtitle: Text(
                          host
                              ? 'Host'
                              : 'Player',
                        ),
                        trailing:
                            const Icon(
                          Icons.check_circle,
                          color: _green,
                        ),
                      ),
                    );
                  }),

                  const SizedBox(height: 14),

                  if (isHost)
                    FilledButton.icon(
                      onPressed:
                          players.isEmpty ||
                                  status ==
                                      'playing'
                              ? null
                              : () async {
                                  try {
                                    final uids =
                                        players
                                            .map(
                                              (doc) =>
                                                  doc.id,
                                            )
                                            .toList();

                                    final gameState =
                                        _dealCards(
                                      game,
                                      uids,
                                    );

                                    await state.fb
                                        .startGame(
                                      roomId:
                                          roomId,
                                      gameState:
                                          gameState,
                                    );
                                  } catch (e) {
                                    if (context
                                        .mounted) {
                                      ScaffoldMessenger
                                          .of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          content:
                                              Text(
                                            e.toString(),
                                          ),
                                        ),
                                      );
                                    }
                                  }
                                },
                      icon: const Icon(
                        Icons.style,
                      ),
                      label: Text(
                        status == 'playing'
                            ? 'GAME STARTED'
                            : 'DEAL CARDS & START',
                      ),
                    )
                  else
                    const Text(
                      'Waiting for host to deal cards…',
                    ),

                  const SizedBox(height: 10),

                  OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(
                          text: roomId,
                        ),
                      );

                      if (context.mounted) {
                        ScaffoldMessenger.of(
                          context,
                        ).showSnackBar(
                          const SnackBar(
                            content: Text(
                              'Room code copied',
                            ),
                          ),
                        );
                      }
                    },
                    icon: const Icon(
                      Icons.copy,
                    ),
                    label: const Text(
                      'COPY ROOM CODE',
                    ),
                  ),

                  const SizedBox(height: 8),

                  OutlinedButton.icon(
                    onPressed: () =>
                        _invite(
                      context,
                      room,
                    ),
                    icon: const Icon(
                      Icons.share,
                    ),
                    label: const Text(
                      'INVITE A FRIEND',
                    ),
                  ),

                  if (status == 'playing')
                    Padding(
                      padding:
                          const EdgeInsets.only(
                        top: 12,
                      ),
                      child: FilledButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  TablePage(
                                state: state,
                                roomId: roomId,
                              ),
                            ),
                          );
                        },
                        child: const Text(
                          'OPEN GAME TABLE',
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        );
      },
    );
  }
}

class TablePage extends StatefulWidget {
  final dynamic state;
  final String roomId;

  const TablePage({
    super.key,
    required this.state,
    required this.roomId,
  });

  @override
  State<TablePage> createState() => _TablePageState();
}

class _TablePageState extends State<TablePage> {
  int selected = -1;
  bool _busy = false;
  Timer? _turnTimer;
  int secondsLeft = 30;

  @override
  void dispose() {
    _turnTimer?.cancel();
    super.dispose();
  }

  void _startTimer(bool myTurn) {
    if (!myTurn) {
      _turnTimer?.cancel();
      return;
    }
    if (_turnTimer?.isActive == true) return;
    secondsLeft = 30;
    _turnTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (secondsLeft <= 1) {
        timer.cancel();
        setState(() => secondsLeft = 0);
      } else {
        setState(() => secondsLeft--);
      }
    });
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  List<String> _cardsFrom(dynamic value) => List<String>.from(value ?? const []);

  int _rank(String card) {
    final r = card.substring(0, card.length - 1);
    const ranks = {'A': 1, 'J': 11, 'Q': 12, 'K': 13};
    return int.tryParse(r) ?? ranks[r] ?? 0;
  }

  String _suit(String card) => card.substring(card.length - 1);
  String _value(String card) => card.substring(0, card.length - 1);

  bool _isSequence(List<String> cards) {
    if (cards.length < 3) return false;
    final suits = cards.map(_suit).toSet();
    if (suits.length != 1) return false;
    final ranks = cards.map(_rank).toList()..sort();
    if (ranks.toSet().length != ranks.length) return false;
    for (var i = 1; i < ranks.length; i++) {
      if (ranks[i] != ranks[i - 1] + 1) return false;
    }
    return true;
  }

  bool _isSet(List<String> cards) {
    if (cards.length < 3 || cards.length > 4) return false;
    final values = cards.map(_value).toSet();
    final suits = cards.map(_suit).toSet();
    return values.length == 1 && suits.length == cards.length;
  }

  List<List<int>> _candidateGroups(List<String> hand) {
    final groups = <List<int>>[];
    final n = hand.length;
    for (var mask = 0; mask < (1 << n); mask++) {
      final bits = <int>[];
      for (var i = 0; i < n; i++) {
        if ((mask & (1 << i)) != 0) bits.add(i);
      }
      if (bits.length < 3) continue;
      final cards = bits.map((i) => hand[i]).toList();
      if (_isSequence(cards) || _isSet(cards)) groups.add(bits);
    }
    groups.sort((a, b) => b.length.compareTo(a.length));
    return groups;
  }

  bool _validRummy(List<String> hand) {
    if (hand.length != 13) return false;
    final groups = _candidateGroups(hand);
    final memo = <int, bool>{};

    bool search(int mask, int sequenceCount, bool pureSequence) {
      if (mask == 0) return sequenceCount >= 2 && pureSequence;
      final key = (mask << 2) | (sequenceCount > 2 ? 2 : sequenceCount) | (pureSequence ? 4 : 0);
      if (memo.containsKey(key)) return memo[key]!;

      final first = _firstBit(mask);
      for (final group in groups) {
        if (!group.contains(first)) continue;
        var gMask = 0;
        for (final i in group) gMask |= 1 << i;
        if ((mask & gMask) != gMask) continue;
        final cards = group.map((i) => hand[i]).toList();
        final seq = _isSequence(cards);
        if (search(mask ^ gMask, sequenceCount + (seq ? 1 : 0), pureSequence || seq)) {
          memo[key] = true;
          return true;
        }
      }
      memo[key] = false;
      return false;
    }

    return search((1 << hand.length) - 1, 0, false);
  }

  int _firstBit(int mask) {
    for (var i = 0; i < 31; i++) {
      if ((mask & (1 << i)) != 0) return i;
    }
    return 0;
  }

  Future<void> _update(
    DocumentSnapshot<Map<String, dynamic>> snap,
    Map<String, dynamic> gameState, {
    int? nextTurn,
  }) async {
    await widget.state.fb.updateGameState(
      widget.roomId,
      gameState,
      turnIndex: nextTurn,
      turn: ((snap.data()?['turn'] ?? 0) as int) + 1,
    );
  }

  Future<void> _drawFromDeck(DocumentSnapshot<Map<String, dynamic>> snap) async {
    if (_busy) return;
    final data = snap.data() ?? {};
    final game = (data['game'] ?? 'rummy').toString();
    if (game != 'rummy') return _playGeneric(snap);
    final members = _cardsFrom(data['memberUids']);
    final turnIndex = (data['turnIndex'] ?? 0) as int;
    final uid = widget.state.uid?.toString() ?? '';
    if (members.isNotEmpty && members[turnIndex % members.length] != uid) {
      return _toast('Wait for your turn');
    }
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    if ((gs['phase'] ?? 'draw') != 'draw') return _toast('Discard a card to finish this turn');
    final deck = _cardsFrom(gs['deck']);
    if (deck.isEmpty) return _toast('Deck is empty');
    final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
    final mine = _cardsFrom(hands[uid]);
    mine.add(deck.removeLast());
    hands[uid] = mine;
    gs['deck'] = deck;
    gs['hands'] = hands;
    gs['phase'] = 'discard';
    setState(() => selected = -1);
    await _update(snap, gs);
  }

  Future<void> _drawFromDiscard(DocumentSnapshot<Map<String, dynamic>> snap) async {
    if (_busy) return;
    final data = snap.data() ?? {};
    final game = (data['game'] ?? 'rummy').toString();
    if (game != 'rummy') return;
    final members = _cardsFrom(data['memberUids']);
    final turnIndex = (data['turnIndex'] ?? 0) as int;
    final uid = widget.state.uid?.toString() ?? '';
    if (members.isNotEmpty && members[turnIndex % members.length] != uid) return _toast('Wait for your turn');
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    if ((gs['phase'] ?? 'draw') != 'draw') return _toast('You already drew a card');
    final discard = _cardsFrom(gs['discardPile']);
    if (discard.isEmpty) return _toast('No discard card available');
    final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
    final mine = _cardsFrom(hands[uid]);
    mine.add(discard.removeLast());
    hands[uid] = mine;
    gs['discardPile'] = discard;
    gs['hands'] = hands;
    gs['phase'] = 'discard';
    setState(() => selected = -1);
    await _update(snap, gs);
  }

  Future<void> _discard(DocumentSnapshot<Map<String, dynamic>> snap) async {
    if (_busy) return;
    final data = snap.data() ?? {};
    final game = (data['game'] ?? 'rummy').toString();
    if (game != 'rummy') return _playGeneric(snap);
    final members = _cardsFrom(data['memberUids']);
    final turnIndex = (data['turnIndex'] ?? 0) as int;
    final uid = widget.state.uid?.toString() ?? '';
    if (members.isNotEmpty && members[turnIndex % members.length] != uid) return _toast('Wait for your turn');
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    if ((gs['phase'] ?? 'draw') != 'discard') return _toast('Draw a card first');
    final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
    final mine = _cardsFrom(hands[uid]);
    if (selected < 0 || selected >= mine.length) return _toast('Select a card to discard');
    final card = mine.removeAt(selected);
    final discard = _cardsFrom(gs['discardPile'])..add(card);
    hands[uid] = mine;
    gs['hands'] = hands;
    gs['discardPile'] = discard;
    gs['phase'] = 'draw';
    final next = members.isEmpty ? 0 : (turnIndex + 1) % members.length;
    setState(() => selected = -1);
    await _update(snap, gs, nextTurn: next);
  }

  Future<void> _drop(DocumentSnapshot<Map<String, dynamic>> snap) async {
    final data = snap.data() ?? {};
    final uid = widget.state.uid?.toString() ?? '';
    final dropped = _cardsFrom((data['gameState'] ?? {})['droppedUids'])..add(uid);
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    gs['droppedUids'] = dropped.toSet().toList();
    gs['phase'] = 'draw';
    final members = _cardsFrom(data['memberUids']);
    final turnIndex = (data['turnIndex'] ?? 0) as int;
    final next = members.isEmpty ? 0 : (turnIndex + 1) % members.length;
    await _update(snap, gs, nextTurn: next);
  }

  Future<void> _declare(DocumentSnapshot<Map<String, dynamic>> snap) async {
    final data = snap.data() ?? {};
    final uid = widget.state.uid?.toString() ?? '';
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
    final mine = _cardsFrom(hands[uid]);
    if (mine.length != 13) return _toast('You need 13 cards to declare');
    if (!_validRummy(mine)) return _toast('Invalid hand — need 2 sequences including 1 pure sequence');
    gs['winnerUid'] = uid;
    gs['result'] = 'VALID DECLARE';
    gs['phase'] = 'finished';
    await _update(snap, gs);
    _toast('Pure Sequence / valid Rummy declared');
  }

  Future<void> _playGeneric(DocumentSnapshot<Map<String, dynamic>> snap) async {
    final data = snap.data() ?? {};
    final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
    final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
    final uid = widget.state.uid?.toString() ?? '';
    final mine = _cardsFrom(hands[uid]);
    if (selected < 0 || selected >= mine.length) return _toast('Select a card first');
    mine.removeAt(selected);
    hands[uid] = mine;
    gs['hands'] = hands;
    final members = _cardsFrom(data['memberUids']);
    final turnIndex = (data['turnIndex'] ?? 0) as int;
    final next = members.isEmpty ? 0 : (turnIndex + 1) % members.length;
    setState(() => selected = -1);
    await _update(snap, gs, nextTurn: next);
  }

  void _sortCards(List<String> cards) {
    cards.sort((a, b) {
      final suit = _suit(a).compareTo(_suit(b));
      if (suit != 0) return suit;
      return _rank(a).compareTo(_rank(b));
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: widget.state.fb.room(widget.roomId),
      builder: (context, snap) {
        if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        if (snap.hasError) return Scaffold(body: Center(child: Text('Game error: ${snap.error}')));
        final data = snap.data!.data() ?? {};
        final game = (data['game'] ?? 'rummy').toString();
        final gs = Map<String, dynamic>.from(data['gameState'] ?? {});
        final hands = Map<String, dynamic>.from(gs['hands'] ?? {});
        final uid = widget.state.uid?.toString() ?? '';
        final mine = _cardsFrom(hands[uid]);
        final members = _cardsFrom(data['memberUids']);
        final turnIndex = (data['turnIndex'] ?? 0) as int;
        final myTurn = members.isEmpty || members[turnIndex % members.length] == uid;
        final phase = (gs['phase'] ?? (game == 'rummy' ? 'draw' : 'play')).toString();
        _startTimer(myTurn);

        final discard = _cardsFrom(gs['discardPile']);
        final community = _cardsFrom(gs['community']);
        final isRummy = game == 'rummy';
        final dropped = _cardsFrom(gs['droppedUids']).contains(uid);
        final finished = phase == 'finished';

        return Scaffold(
          appBar: AppBar(
            title: Text('${_gameTitle(game)} Table'),
            backgroundColor: _redDark,
            foregroundColor: Colors.white,
            actions: [
              if (isRummy)
                IconButton(
                  tooltip: 'Auto Sort',
                  onPressed: () => setState(() => _sortCards(mine)),
                  icon: const Icon(Icons.sort),
                ),
            ],
          ),
          body: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF071B16), Color(0xFF0B5A3C), Color(0xFF063C2A)],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  const SizedBox(height: 10),
                  Text(
                    isRummy ? '13-card Points Rummy' : '${_gameTitle(game)} game',
                    style: const TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    finished ? 'GAME FINISHED' : dropped ? 'YOU DROPPED' : (myTurn ? 'YOUR TURN' : 'WAITING FOR OPPONENT'),
                    style: TextStyle(color: finished ? _green : (myTurn ? Colors.amber : Colors.white70), fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                  if (myTurn && !finished) Text('Time: $secondsLeft s', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  if (isRummy)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Row(
                        children: [
                          Expanded(child: _pileButton('DRAW', Icons.style, onPressed: myTurn && phase == 'draw' && !dropped && !finished ? () => _drawFromDeck(snap.data!) : null)),
                          const SizedBox(width: 8),
                          Expanded(child: _pileButton('DISCARD', Icons.layers, onPressed: myTurn && phase == 'draw' && discard.isNotEmpty && !dropped && !finished ? () => _drawFromDiscard(snap.data!) : null, subtitle: discard.isEmpty ? 'empty' : discard.last)),
                        ],
                      ),
                    ),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        children: [
                          if (!isRummy && community.isNotEmpty) _section('TABLE', Wrap(spacing: 8, children: community.map((c) => _playingCard(c, false)).toList())),
                          if (isRummy) ...[
                            _section('OPEN DISCARD', discard.isEmpty ? const Text('No discard card', style: TextStyle(color: Colors.white54)) : _playingCard(discard.last, false)),
                            const SizedBox(height: 10),
                          ],
                          _section(
                            'YOUR CARDS (${mine.length})',
                            Wrap(
                              spacing: 6,
                              runSpacing: 9,
                              alignment: WrapAlignment.center,
                              children: List.generate(mine.length, (index) {
                                final canTap = myTurn && !finished && !dropped && (!isRummy || phase == 'discard');
                                return GestureDetector(
                                  onTap: canTap ? () => setState(() => selected = index) : null,
                                  child: _playingCard(mine[index], selected == index),
                                );
                              }),
                            ),
                          ),
                          if (isRummy) ...[
                            const SizedBox(height: 10),
                            const Align(
                              alignment: Alignment.centerLeft,
                              child: Text('Rummy requires 2 sequences, including 1 pure sequence.', style: TextStyle(color: Colors.white70)),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  if (!finished && !dropped)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(14, 6, 14, 14),
                      child: Row(
                        children: [
                          if (isRummy) ...[
                            Expanded(child: OutlinedButton(onPressed: myTurn && phase == 'discard' ? () => _discard(snap.data!) : null, child: const Text('DISCARD SELECTED'))),
                            const SizedBox(width: 7),
                            Expanded(child: OutlinedButton(onPressed: myTurn ? () => _drop(snap.data!) : null, child: const Text('DROP'))),
                            const SizedBox(width: 7),
                            Expanded(child: FilledButton(onPressed: myTurn && mine.length == 13 ? () => _declare(snap.data!) : null, child: const Text('DECLARE'))),
                          ] else
                            Expanded(child: FilledButton(onPressed: myTurn && selected >= 0 ? () => _playGeneric(snap.data!) : null, child: const Text('PLAY / DISCARD'))),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _section(String title, Widget child) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.22), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white24)),
      child: Column(children: [Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 10), child]),
    );
  }

  Widget _pileButton(String label, IconData icon, {required VoidCallback? onPressed, String? subtitle}) {
    return FilledButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Column(mainAxisSize: MainAxisSize.min, children: [Text(label), if (subtitle != null) Text(subtitle, style: const TextStyle(fontSize: 10))]),
      style: FilledButton.styleFrom(backgroundColor: _red, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 9)),
    );
  }

  Widget _playingCard(String card, bool selectedCard) {
    final isRed = card.contains('♥') || card.contains('♦');
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: 56,
      height: 80,
      transform: Matrix4.translationValues(0, selectedCard ? -8 : 0, 0),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(9), border: Border.all(color: selectedCard ? Colors.amber : Colors.black26, width: selectedCard ? 3 : 1), boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 5, offset: Offset(0, 3))]),
      child: Center(child: Text(card, textAlign: TextAlign.center, style: TextStyle(color: isRed ? _red : Colors.black87, fontSize: 19, fontWeight: FontWeight.w900))),
    );
  }
}
