# Royal Cards 2.0

Virtual-coin card-game app based on the working Royal Cards build.

Included in this build:
- Rummy, Teen Patti, Poker and Andar Bahar game hubs
- Online room create/join UI
- Friend invite flow
- Email ID and phone number account fields
- Virtual wallet and leaderboard
- Admin dashboard UI
- Existing GitHub Actions APK workflow

Important: the current source does not include a Firebase Android configuration or backend credentials. The online room UI and local room state are included, but true cross-device real-time multiplayer, verified email/phone authentication, and server-side admin controls require connecting the app to the user's Firebase project. No real-money wagering is implemented.

## Build note
The GitHub Actions workflow preserves `lib/main.dart` when generating the Android host project. This prevents Flutter's default counter demo from replacing the Royal Cards app entrypoint.
